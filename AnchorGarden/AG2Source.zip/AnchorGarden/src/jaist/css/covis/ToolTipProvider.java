package jaist.css.covis;

import edu.umd.cs.piccolo.PNode;

public interface ToolTipProvider {
	PNode getToolTipNode();
}
