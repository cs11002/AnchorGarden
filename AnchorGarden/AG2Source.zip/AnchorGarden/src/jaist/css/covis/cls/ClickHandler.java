package jaist.css.covis.cls;

import jaist.css.covis.fm.FlowMenu_TMRG;
import edu.umd.cs.piccolo.event.PInputEvent;

public interface ClickHandler {
	public void clicked(PInputEvent e, FlowMenu_TMRG fmenu);
}
