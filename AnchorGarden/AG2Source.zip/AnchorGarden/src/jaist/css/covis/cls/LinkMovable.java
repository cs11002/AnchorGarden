package jaist.css.covis.cls;

public interface LinkMovable {
	public void update();
}
