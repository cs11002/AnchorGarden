package jaist.css.covis.cls;

import edu.umd.cs.piccolo.util.PDimension;

public interface Move {
	public void move(PDimension d);
}
