package jaist.css.covis.cls;

public interface ToFront {
	public void toFront(long ts);
}
