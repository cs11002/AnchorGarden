package jaist.css.covis.mi;


public interface InputField {
	public String getType();
	public String getSelectedItemString();
	public Object getSelectedItemObject();
	public void setType(String s);

}
