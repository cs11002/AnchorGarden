package jaist.css.covis.pui;

import java.awt.Color;

/**
 * ��ʓI�ȕ����񃉃x��������PMenuItem
 * @author miuramo
 *
 */
public class PMenuItem_String extends PMenuItem_Abstract {
	private static final long serialVersionUID = 1789811891741678164L;

	public PMenuItem_String(String arg, boolean m, Color c) {
		super(arg, m, c);
	}
}
