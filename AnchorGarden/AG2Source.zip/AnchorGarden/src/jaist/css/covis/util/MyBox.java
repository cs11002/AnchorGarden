package jaist.css.covis.util;

public interface MyBox {
	public double getWidth();
	public double getHeight();
	public String toString();
}
